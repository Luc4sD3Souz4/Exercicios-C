void encontrarErro ();
void encontrarErro () {
	printf("*****\n"); 
    printf("*****\n"); 
    printf("*****\n"); 
    printf("*****\n"); 
    printf("*****\n"); 
    printf("%d\n", EXIT_SUCCESS);
    system("PAUSE");
}
