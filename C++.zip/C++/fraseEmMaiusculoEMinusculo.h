void fraseMaiEMin ();
void fraseMaiEMin () {
	setlocale(LC_ALL, "Portuguese");

	char frase[256];

	printf("Escreva uma frase: ");
	gets(frase);

	printf("\nFrase em mai�sculo: %s", strupr(frase));
	printf("\nFrase em min�sculo: %s", strlwr(frase));
}
