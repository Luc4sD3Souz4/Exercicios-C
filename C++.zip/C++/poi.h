void parOuImpar ();
void parOuImpar () {
	int   resto,
		  numero;
		resto = 0;
		numero = 0;

		printf("********************\n");
		printf("Digite um numero\n");
		scanf("%d",&numero);
		printf("********************\n");
		resto = numero % 2;
	    if(resto==0){
	    	printf("Seu numero e par\n\n");
	    }else{
	    	printf("Seu numero e impar\n\n");	
	    }
}
