void deslocaEsq(char *sVetor, int iIndice){
	for(int i = iIndice; i < strlen(sVetor); i++){
		sVetor[i] = sVetor[i+1];
	}
}

int semEspacos(){
	char sVetor[40];
	int i;
	printf("Digite a frase: ");
	gets(sVetor);
	fgets(sVetor, 40, stdin);
	sVetor[strlen(sVetor)-1] = '\0';
	
	for(i = 0; i < strlen(sVetor); i++) while (sVetor[i] == ' ') deslocaEsq(sVetor, i);
	
	printf("Frase Modificada: %s", sVetor);
	system("pause>>NULL");
}
