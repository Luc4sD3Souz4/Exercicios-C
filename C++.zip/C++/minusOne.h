void menosUm ();
void menosUm () {
	int numero,
	    resposta;	    
	printf("Digite um numero inteiro qualquer: ");
	scanf("%d",&numero);
	resposta = numero - 1;
	printf("%d", resposta);
}
