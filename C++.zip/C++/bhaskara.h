void bhaskara ();
void bhaskara () {
	float a,
		  b,
	  	  c,
	  	  delta,
		  x1,
		  x2;
		
	printf("Digite o valor de 'a': ");
	scanf("%f",&a);
	printf("Digite o valor de 'b': ");
	scanf("%f",&b);
	printf("Digite o valor de 'c': ");
	scanf("%f",&c);
	delta = b * b - 4 * a * c;
	x1 = (-b + sqrt(delta)) / (2 * a);
	x2 = (-b - sqrt(delta)) / (2 * a);
	printf("X1 = %.2f\n", x1);
	printf("X2 = %.2f", x2);
}
