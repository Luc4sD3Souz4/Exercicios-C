void voc ();
void voc () {
	char letra;
    printf("\n Informe uma letra qualquer\n\n");
    scanf("%c",&letra);
    letra = toupper(letra);
    if(letra=='A' || letra=='E' || letra=='I' || letra=='O' || letra=='U'){
        printf("Sua letra e uma vogal");
    }else{
        printf("Sua letra e uma consoante");
    }
}
