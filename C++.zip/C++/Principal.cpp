#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <locale.h>
#include <ctype.h>
#include <conio.h>
#include <windows.h>

#include "menu.h"
#include "switch.h"

int main () 
{
	setlocale(LC_ALL, "Portuguese");
	menu ();
	switchzasso ();
	return 0;
}
