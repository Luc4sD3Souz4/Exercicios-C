void maiEMin ();
void maiEMin () {
	char letrasMaiusculas [100];
	int i = 0,
		k = 0,
		tamanhoPalavra;
	setlocale(LC_ALL,"Portuguese");
	printf("Digite uma palavra ou frase: ");
	gets(letrasMaiusculas);
	tamanhoPalavra = strlen(letrasMaiusculas) -1;
	for(i = 0; i <= tamanhoPalavra; i++) {
		if(i %2 == 0) {
			putchar(toupper(letrasMaiusculas[i]));
		} else
			putchar(tolower(letrasMaiusculas[i]));
	}
	printf("\n");
	system("pause");
}
