#include "helloWorld.h"
#include "goodNight.h"
#include "personalInfo.h"
#include "poi.h"
#include "f.h"
#include "bhaskara.h"
#include "fifthDivisor.h"
#include "minusOne.h"
#include "salary.h"
#include "largerNumber.h"
#include "salaryIncrease.h"
#include "rectangle.h"
#include "imc.h"
#include "trocaDeValores.h"
#include "salarioMensal.h"
#include "horasEmSegundos.h"
#include "rola.h"
#include "triangle.h"
#include "circle.h"
#include "findError.h"
#include "vogalOuConsoante.h"
#include "avaliation.h"
#include "details.h"
#include "maiusculasEMinusculas.h"
#include "encontrarPalavra.h"
#include "espacosEntreAsPalavras.h"
#include "fraseEmMaiusculoEMinusculo.h"
#include "entreOsNumeros.h"
#include "dezNumeros.h"
#include "trianguloDeAsteriscos.h"
#include "trianguloDeNumeros.h"
#include "natal.h"
#include "tabuada.h"
#include "semEspacos.h"

void switchzasso ();
void switchzasso () {
	int opcao;
	
	scanf("%d",&opcao);
		
		switch(opcao)
		{
			case 0:
				system ("cls");
				olaMundo();
				break;
			case 1:
				system ("cls");
				boaNoite();
				break;
			case 2:
				system ("cls");
				infoPessoal();
				break;
			case 3:
				system ("cls");
				parOuImpar();
				break;
			case 4:
				system ("cls");
				efe();
				break;
			case 5:
				system ("cls");
				bhaskara();
				break;
			case 6:
				system ("cls");
				divPorCinco();
				break;
			case 7:
				system ("cls");
				menosUm();
				break;
			case 8:
				system ("cls");
				salario();
				break;
			case 9:
				system ("cls");
				maiorNumero();
				break;
			case 10:
				system ("cls");
				aumento();
				break;	
			case 11:
				system ("cls");
				retangulo();
				break;
			case 12:
				system ("cls");
				imc();
				break;
			case 13:
				system ("cls");
				trocaTroca();
				break;
			case 14:
				system ("cls");
				mensalidade();
				break;
			case 15:
				system ("cls");
				horasSec();
				break;
			case 16:
				system ("cls");
				triangulo();
				break;
			case 17:
				system ("cls");
				circulo();
				break;
			case 18:
				system ("cls");
				encontrarErro();
				break;
			case 19:
				system ("cls");
				voc();
				break;
			case 20:
				system ("cls");
				avaliacao();
				break;
			case 21:
				system ("cls");
				detalhes();
				break;	
			case 22:
				system ("cls");
				maiEMin();
				break;
			case 23:
				system ("cls");
				encontrei();
				break;
			case 24:
				system ("cls");
				espacos();
				break;
			case 25:
				system ("cls");
				fraseMaiEMin();
				break;
			case 26:
				system ("cls");
				entreNumeros();
				break;
			case 27:
				system ("cls");
				dezNum();
				break;
			case 28:
				system ("cls");
				triDeAsteriscos();
				break;
			case 29:
				system ("cls");
				triDeNumeros();
				break;
			case 30:
				system ("cls");
				arvoreDeNatal();
				break;
			case 31:
				system ("cls");
				tabuada();
				break;
			case 32:
				system ("cls");
				semEspacos();
				break;
			case 666:
				system ("cls");
				rola();
				break;
		}
}
