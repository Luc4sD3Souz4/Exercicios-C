void imc ();
void imc () {
	float massa,
		  altura,
		  imc;
	
	printf("Digite sua altura (em metros): ");
	scanf("%f",&altura);
	printf("Digite sua massa (em quilos): ");
	scanf("%f",&massa);
	imc = massa / (altura * altura);
	printf("IMC = %.2f", imc);
}
