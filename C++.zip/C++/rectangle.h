void retangulo ();
void retangulo () {
	int ladoUm,
		ladoDois,
		perimetro,
		area;

	printf("Digite o valor da base do retangulo: ");
	scanf("%d",&ladoUm);
	printf("Digite o valor do lado do retangulo: ");
	scanf("%d",&ladoDois);
	area = ladoUm * ladoDois;
	perimetro = ladoUm * 2 + ladoDois * 2;
	printf("Perimetro do retangulo = %d\n", perimetro);
	printf("Area do retangulo = %d", area);
}
