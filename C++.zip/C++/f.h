void efe ();
void efe () {
	printf("######\n#\n#\n#####\n#\n#\n#");
}
