void olaMundo ();
void olaMundo () {
	printf("\t\t\t############################\n");
	printf("\t\t\t#                          #\n");
	printf("\t\t\t# Ingl�s    - Hello World! #\n");
	printf("\t\t\t# Portugu�s -   Ol� Mundo! #\n");
	printf("\t\t\t# Espanhol  -  Hola Mundo! #\n");
	printf("\t\t\t# Italiano  -  Ciao Mondo! #\n");
	printf("\t\t\t# Russo     - Privet, mir! #\n");
	printf("\t\t\t#                          #\n");
	printf("\t\t\t############################\n");
}
