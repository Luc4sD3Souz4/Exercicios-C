void circulo ();
void circulo () {
	float area,
		  pi,
		  raio;
	printf("Digite o raio de um c�rculo: ");
	scanf("%f",&raio);
	pi = 3.14;
	area = pi * (raio * raio);
	printf("A �rea do c�rculo � %.2f", area);
}
