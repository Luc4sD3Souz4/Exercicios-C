void infoPessoal ();
void infoPessoal () {
	char nome[256];
	int telefone,
		dia,
		ano,
		mes;
		
	printf("Digite o seu nome: ");
	gets(nome);
	fgets(nome, sizeof(nome), stdin);
	strtok(nome, "\n");
	printf("Digite o dia do seu anivers�rio: ");
	scanf("%d",&dia);
	printf("Digite o m�s do seu anivers�rio: ");
	scanf("%d",&mes);
	printf("Digite o ano em que voc� nasceu: ");
	scanf("%d",&ano);
	printf("Digite seu n�mero de telefone: ");
	scanf("%d",&telefone);
	system("cls");
	printf("%s, voc� nasceu em %d / %d / %d ", nome, dia, mes, ano);
	printf("e seu telefone � %d", telefone);
}
