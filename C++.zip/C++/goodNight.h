void boaNoite ();
void boaNoite () {
	char nome[256];
	
	printf("\t\t\tQual � o seu nome?\n\n\t\t\t");
	gets(nome);
	fgets(nome, sizeof(nome), stdin);
	strtok(nome, "\n");
	system ("cls");
	printf("\t\t\t##################==---\n");
	printf("\t\t\t#              \n");
	printf("\t\t\t# Boa noite, %s\n", nome);
	printf("\t\t\t#              \n");
	printf("\t\t\t##################==---");
}
